// Home.jsx
import React from 'react';
import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <div className="content">
        <h1 className="title">fixNgo</h1>
        <p className="description">Your Car, Our Care</p>
        
      </div>
    </div>
  );
};

export default Home;
